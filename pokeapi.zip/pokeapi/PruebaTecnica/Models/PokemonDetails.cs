﻿namespace PruebaTecnica.Models
{
    /// <summary>
    /// The Pokemon details model.
    /// </summary>
    public class PokemonDetails
    {

        public string Name { get; set; } = default!;
        public int Height { get; set; }
        public int Weight { get; set; }

        //Completar estos datos.
        public int Attack { get; set; }
        public int HP { get; set; }
        public int Defense { get; set; }
        public int Speed { get; set; }

    }
}
