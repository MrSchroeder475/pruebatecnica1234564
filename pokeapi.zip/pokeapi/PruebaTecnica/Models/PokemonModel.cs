﻿using PruebaTecnica.Controllers;

namespace PruebaTecnica.Models
{
    /// <summary>
    /// The Pokemon model
    /// </summary>
    public class PokemonModel
    {
        public string Name { get; set; } = default!;
        public string Url { get; set; } = default!;
    }
}
