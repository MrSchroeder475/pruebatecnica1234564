﻿using PruebaTecnica.Controllers;

namespace PruebaTecnica.Models.Requests
{
    /// <summary>
    /// The Pokemon results model.
    /// </summary>
    public class PokemonResultModel
    {
        public IEnumerable<Pokemon> Pokemon { get; set; } = default!;
    }
}
