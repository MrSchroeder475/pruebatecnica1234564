﻿namespace PruebaTecnica.Models
{
    public class Pokemon
    {
        public PokemonModel PokemonModel { get; set; }
    }
}
