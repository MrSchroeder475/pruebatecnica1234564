﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PruebaTecnica.Models;
using PruebaTecnica.Models.Requests;
using System.Net.Http;

namespace PruebaTecnica.Controllers
{
    /// <summary>
    /// Pokemon API Controller.
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class PokemonController : Controller
    {


        string baseUrl = "https://pokeapi.co/api/v2/";
        List<string> pokemonTypes = new List<string> {
            "Fire", "Electric", "Water", "Grass"
        };

        /// <summary>
        /// Method that gets the pokemons by a predefined <see cref="types"/>
        /// </summary>
        /// <returns>Returns a list of json with all the pokemons from the predefined types.</returns>
        [HttpGet]
        public IActionResult GetPokemons()
        {
            HttpClient httpClient = new HttpClient();
            httpClient.BaseAddress = new Uri(baseUrl);
            List<PokemonDetails> pokemonInfoDetails = new List<PokemonDetails>();

            foreach (var pokemonType in pokemonTypes)
            {
                try
                {

                    string requestUrlByType = $"{baseUrl}type/{pokemonType.ToLower()}/";
                    HttpResponseMessage responseMessage = httpClient.GetAsync(requestUrlByType).Result;
                    responseMessage.EnsureSuccessStatusCode();
                    string responseContent = responseMessage.Content.ReadAsStringAsync().Result;
                    var jsonContent = JsonConvert.DeserializeObject<PokemonResultModel>(responseContent);


                    foreach (var pokemonModel in jsonContent.Pokemon)
                    {
                        PokemonDetails pokemonDetails = GetPokemonDetails(pokemonModel, httpClient);

                        pokemonInfoDetails.Add(pokemonDetails!);
                    }
                }
                catch (Exception)
                {               
                    Console.WriteLine($"¡Error al buscar el Pokemn de tipo '{pokemonType}'!");
                }
            }
            return Ok(JsonConvert.SerializeObject(pokemonInfoDetails));
        }
     
        PokemonDetails GetPokemonDetails(PokemonModel pokemonModel, HttpClient httpClient)
        {
            string pokemonUrl = pokemonModel.Url;
            HttpResponseMessage pokemonItemResponseMessage = httpClient.GetAsync(pokemonUrl).Result;
            pokemonItemResponseMessage.EnsureSuccessStatusCode();

            string pokemonContent = pokemonItemResponseMessage.Content.ReadAsStringAsync().Result;
            var pokemonDetails = JsonConvert.DeserializeObject<PokemonDetails>(pokemonContent);
            return pokemonDetails!;
        }

    }


}
